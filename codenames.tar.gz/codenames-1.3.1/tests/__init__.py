from utils import configure_logging

configure_logging()
